def add_vaf_svdss(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                var.info['VAF'] = len(var.info['READS'])/(len(var.info['READS']) + var.info['COV'])
                vcf_out.write(var)
            vcf_out.close()
        
        
        def add_vaf_cuteSV(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            t= 0
            for var in vcf_in:
                sample_id = var.samples.keys()[0]
                var.info['VAF'] = var.samples[sample_id]['DV']/60
                vcf_out.write(var)
            vcf_out.close()
        
        def add_vaf_debreak(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            t= 0
            for var in vcf_in:
                var.info['VAF'] = var.info['SUPPREAD']/60
                vcf_out.write(var)
            vcf_out.close()
            
        
        def add_vaf_severus(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                sample_id = var.samples.keys()[0]
                var.info['VAF'] = var.samples[sample_id]['VAF']
                vcf_out.write(var)
        
        def add_vaf_savana(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_in.header.info.add("END",1,"Integer","Stop position of the interval")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                var.info['VAF'] = float(var.info['TUMOUR_SUPPORT']/(np.median(var.info['TUMOUR_DP']) + var.info['TUMOUR_SUPPORT']))
                vcf_out.write(var)
                
        
        def add_vaf_sniffles(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf.gz')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                var.info['VAF'] = var.samples['sniffles_tumor']['DV']/(var.samples['sniffles_tumor']['DV'] + var.samples['sniffles_tumor']['DR'])
                vcf_out.write(var)
        
        
        def add_vaf_nanomonsv(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                var.info['VAF'] = var.samples['TUMOR']['VR']/(var.samples['TUMOR']['TR'] + var.samples['TUMOR']['VR'])
                vcf_out.write(var)
        
        
        def add_vaf_svaba(vcf_in, sample_id):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                var.info['VAF'] = var.samples[sample_id]['AD']/(var.samples[sample_id]['DP'] + var.samples[sample_id]['AD'])
                vcf_out.write(var)
                
        def add_vaf_gripps(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                var.info['VAF'] = var.info['TAF']
                vcf_out.write(var)
                
                
        def add_vaf_manta(vcf_in):
            out_vcf = vcf_in.replace('.vcf' , '_vaf.vcf')
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_in.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                span = 0
                supp = 0
                for key,val in var.format.items():
                    span += var.samples['SAMPLE2'][key][0]
                    supp += var.samples['SAMPLE2'][key][1]
                if supp > 0:
                    var.info['VAF'] = supp / (supp + span)
                vcf_out.write(var)
        
        
        def add_indel_svaba(vcf_sv, vcf_indel):
            vcf_svin=pysam.VariantFile(vcf_sv,"r")
            vcf_indelin=pysam.VariantFile(vcf_indel,"r")
            out_vcf = vcf_svin.replace('.vcf' , 'merged_vaf.vcf')
            vcf_svin.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_indelin.header.info.add("VAF",1,"Float","variant_allele_frequency")
            vcf_svin.header.info.add("SVLEN",1,"Float","SVLENGTH")
            vcf_indelin.header.info.add("SVLEN",1,"Float","SVLENGTH")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_svin.header)
            sample_id = '/data/KolmogorovLab/HG008/illumina/HG008-T_subsample.bam'
            formats = ['GT', 'AD','DP','GQ','PL','SR','LR','LO']
            for rec in vcf_svin:
                rec.info['VAF'] = rec.samples[sample_id]['AD']/(rec.samples[sample_id]['DP'] + rec.samples[sample_id]['AD'])
                vcf_out.write(rec)
            for var in vcf_indelin:
                if max([len(a) for a in var.alts]) > 49:
                    rec.info['VAF'] = var.samples[sample_id]['AD']/(var.samples[sample_id]['DP'] + var.samples[sample_id]['AD'])
                    rec.alts = var.alts
                    rec.ref = var.ref
                    rec.pos = var.pos
                    rec.chrom = var.chrom
                    rec.info['SVLEN'] = max([len(a) for a in var.alts])
                    for ff in formats:
                        rec.samples[sample_id][ff] = var.samples[sample_id][ff]
                    vcf_out.write(rec)
                if len(var.ref) > 49:
                    rec.info['VAF'] = var.samples[sample_id]['AD']/(var.samples[sample_id]['DP'] + var.samples[sample_id]['AD'])
                    rec.alts = ('N[' + var.chrom + ':' + str(var.pos + len(var.ref)) + '[',)
                    rec.ref = 'N'
                    rec.pos = var.pos
                    rec.chrom = var.chrom
                    rec.info['SVLEN'] = len(var.ref)
                    for ff in formats:
                        rec.samples[sample_id][ff] = var.samples[sample_id][ff]
                    vcf_out.write(rec)
            vcf_out.close()
