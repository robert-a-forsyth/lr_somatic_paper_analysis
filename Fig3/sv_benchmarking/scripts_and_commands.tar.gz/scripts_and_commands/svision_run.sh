#!/bin/bash
# Svision-pro v2.0

TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

################ SVision

SVision-pro --target_path $TUMOR_BAM --genome_path $REF --model_path SVision/model_liteunet_256_8_16_32_32_32.pth --out_path $OUT_DIR --sample_name $NAME--detect_mode germline --process_num 32

#### truvari subtraction (v4.1)

mamba activate truvari

truvari bench -c $CALLER_VCF -b $TRUTH_VCF--typeignore --dup-to-ins -p 0 -s 30 -S 0 --sizemax 100000000 -o truvari_output --passonly

###### jasmine (v1.1.5)
mamba activate jasminesv
ls *.vcf > filelist.txt
jasmine file_list=filelist.txt --dup_to_ins max_dist 500 genome_file=$REF out_file=merged.vcf
bcftools view -i "SUPP_VEC = '01'" merged.vcf > merge_somatic_only.vcf
bgzip -c merge_somatic_only.vcf > merge_somatic_only.vcf.gz
tabix merge_somatic_only.vcf.gz 


