#!/bin/bash
# NanomonsV v0.6.0
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

############# NANOMONSV

mkdir $OUT_DIR
mkdir $OUT_DIR/tumor
mkdir $OUT_DIR/normal

# parameters
SIZE=50
#SIZE=30 for COLO829

mamba activate nanomonsv
#-----parse-----
nanomonsv parse ${TUMOR_BAM} $OUT_DIR/tumor
nanomonsv parse ${NORMAL_BAM} $OUT_DIR/normal
#----get----
nanomonsv get $OUT_DIR/tumor ${TUMOR_BAM} $REF \
--control_prefix $OUT_DIR/normal --control_bam ${NORMAL_BAM} \
--use_racon \
--single_bnd \
--min_indel_size $SIZE \
--debug
