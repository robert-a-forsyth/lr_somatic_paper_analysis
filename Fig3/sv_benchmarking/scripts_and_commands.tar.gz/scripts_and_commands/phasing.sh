#! /bin/bash

# v0.8
module load singularity
module load parallel
module load CUDA/11.3.0
module load python/3.8

SAMPLE_NAME_N=$1
BAM_N=$2
PEPPER_OUT=$3
REF=4


singularity run --nv -B /data/ pepper_deepvariant_r0.8-gpu.sif run_pepper_margin_deepvariant call_variant -b ${BAM_N} -f $REF -o ${PEPPER_OUT} -p ${SAMPLE_NAME_N} -t 56 --ont_r10_q20 --phased_output --gpu

