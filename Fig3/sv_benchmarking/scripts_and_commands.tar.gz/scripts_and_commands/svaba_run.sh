#!/bin/bash
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

### SVABA v 1.2.0
svaba/bin/svaba run -t $TUMOR_BAM -n ${NORMAL_BAM} -G $REF -p 32  -a $OUT_DIR
