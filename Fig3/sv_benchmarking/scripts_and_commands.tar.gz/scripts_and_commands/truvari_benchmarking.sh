#!/bin/bash
# truvari v 4.1
mamba activate truvari

truvari bench -c $CALLER_VCF -b $TRUTH_VCF--typeignore --dup-to-ins -p 0 -s 30 -S 0 --sizemax 100000000 -o truvari_output --passonly
