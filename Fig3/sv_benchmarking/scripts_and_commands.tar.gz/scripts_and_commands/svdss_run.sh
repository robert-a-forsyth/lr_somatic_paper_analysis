#!bin/bash
#SVDSS2 (v 2.0)
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

BAM2=$OUT_DIR/smoothed.bam
mkdir -p $OUT_DIR
SVDSS smooth --reference $REF --bam $TUMOR_BAM --threads 32 > $BAM2
SVDSS search --index $REF.fmd --bam $BAM2 --threads 32 > $OUT_DIR/specifics.txt
samtools index -@ 32 $BAM2
SVDSS call --reference $REF --bam $BAM2 --sfs $OUT_DIR/specifics.txt --threads 32 --min-cluster-weight 4 > $OUT/svdss_4.vcf

#### truvari subtraction (v4.1)

mamba activate truvari

truvari bench -c $CALLER_VCF -b $TRUTH_VCF--typeignore --dup-to-ins -p 0 -s 30 -S 0 --sizemax 100000000 -o truvari_output --passonly

###### jasmine (v1.1.5)
mamba activate jasminesv
ls *.vcf > filelist.txt
jasmine file_list=filelist.txt --dup_to_ins max_dist 500 genome_file=$REF out_file=merged.vcf
bcftools view -i "SUPP_VEC = '01'" merged.vcf > merge_somatic_only.vcf
bgzip -c merge_somatic_only.vcf > merge_somatic_only.vcf.gz
tabix merge_somatic_only.vcf.gz 


