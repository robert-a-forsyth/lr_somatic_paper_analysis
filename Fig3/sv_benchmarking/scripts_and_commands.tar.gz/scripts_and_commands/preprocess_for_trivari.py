### VCF PREPROCESS for truvari python
# Truvari cannot handle duplicate BND records so we need to filter them first

        # for nanomonsv
        for vcf_in in vcfs:
            out_vcf = 'truvari_vcfs/' + vcf_in + '.gz'
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                if not var.id.endswith('_1'):
                    vcf_out.write(var)
            vcf_out.close()
        
        # Severus and Savana 
        for vcf_in in vcfs:
            out_vcf = 'truvari_vcfs/' + vcf_in + '.gz'
            vcf_in=pysam.VariantFile(vcf_in,"r")
            vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
            for var in vcf_in:
                if not var.id.endswith('_2'):
                    vcf_out.write(var)
            vcf_out.close()
                
        #SVABA
        vcf_in = 'svaba.vcf'
        out_vcf = 'truvari_vcfs/' + vcf_in + '.gz'
        vcf_in=pysam.VariantFile(vcf_in,"r")
        vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
        for var in vcf_in:
            if not var.info['MATEID'].endswith(':2'):
                vcf_out.write(var)
        vcf_out.close()        
            
        
        #GRIPPSS
        
        out_vcf = 'truvari_vcfs/' + vcf_in + '.gz'
        vcf_in=pysam.VariantFile(vcf_in,"r")
        vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
        for var in vcf_in:
            if not var.id.endswith('h'):
                vcf_out.write(var)
        vcf_out.close()
            
        # MANTA
        vcf_in = 'manta.vcf'
        out_vcf = 'truvari_vcfs/' + vcf_in + '.gz'
        vcf_in=pysam.VariantFile(vcf_in,"r")
        vcf_out = pysam.VariantFile(out_vcf, 'w', header=vcf_in.header)
        for var in vcf_in:
            if not var.id.endswith(':1'):
                vcf_out.write(var)
        vcf_out.close() 
