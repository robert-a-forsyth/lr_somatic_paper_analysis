#!bin/bash
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

#ONT
cuteSV  $TUMOR_BAM $REF $OUT_DIR/cuteSV/cuteSV_t.vcf $OUT_DIR/cuteSV--max_cluster_bias_INS 100 --diff_ratio_merging_INS 0.3 --max_cluster_bias_DEL 100 --diff_ratio_merging_DEL 0.3 -t 32
#PB
cuteSV $TUMOR_BAM $REF $OUT_DIR/cuteSV/cuteSV_t.vcf $OUT_DIR/cuteSV --max_cluster_bias_INS 1000 --diff_ratio_merging_INS 0.9 --max_cluster_bias_DEL 1000 --diff_ratio_merging_DEL 0.5 -t 32


#### truvari subtraction (v4.1)

mamba activate truvari

truvari bench -c $CALLER_VCF -b $TRUTH_VCF--typeignore --dup-to-ins -p 0 -s 30 -S 0 --sizemax 100000000 -o truvari_output --passonly

###### jasmine (v1.1.5)
mamba activate jasminesv
ls *.vcf > filelist.txt
jasmine file_list=filelist.txt --dup_to_ins max_dist 500 genome_file=$REF out_file=merged.vcf
bcftools view -i "SUPP_VEC = '01'" merged.vcf > merge_somatic_only.vcf
bgzip -c merge_somatic_only.vcf > merge_somatic_only.vcf.gz
tabix merge_somatic_only.vcf.gz 
