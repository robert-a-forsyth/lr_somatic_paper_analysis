#! /bin/bash
source myconda
conda activate whatshap-env

SAMPLE_T=$1
BAM_T=$2
VCF=$3
REF_FASTA=$4 
whatshap haplotag --reference ${REF_FASTA} ${VCF} ${BAM_T} -o ${SAMPLE_T}.haplotagged.bam --ignore-read-groups --tag-supplementary --skip-missing-contigs --output-threads=4
