#!/bin/bash
TUM_NAME=$1
NORM_NAME=$2
GRIDSS_OUT=$3
OUTPUT=$4

#GRIDSS v2.13.2
gridss --reference $REF --output ${OUTPUT_DIR}/${OUTPUT} --workingdir ${OUTPUT_DIR} --t 8 $TUMOR_BAM ${NORMAL_BAM}

## GRIPSS RUN v2.2
java -jar /data/KolmogorovLab/keskusa2/tools/gripss_v2.2.jar \
   -sample ${TUM_NAME} \
   -reference ${NORM_NAME} \
   -ref_genome_version 38 \
   -ref_genome $REF\
   -vcf ${GRIDSS_OUT} \
   -output_dir gripss/${OUTPUT}
