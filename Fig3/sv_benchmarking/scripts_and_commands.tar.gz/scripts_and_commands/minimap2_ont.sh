#!/bin/bash
module load minimap2
module load samtools
BAM_PATH=$1
REF_PATH=$2
OUT_PATH=$3
SAMPLE_NAME=$4

cd ${OUT_PATH}
samtools fastq -T MM,ML ${BAM_PATH} | minimap2 -ax map-ont ${REF_PATH} - -k 17 -y -K 5G -t 56 --eqx | samtools sort -@4 -m 4G > ${SAMPLE_NAME}.bam
samtools index -@56 ${SAMPLE_NAME}.bam

#sbatch --gres=lscratch:2000  --cpus-per-task=56 --time 48:00:00 --mail-type=END methylation_alignment.sh BAM_PATH REF_PATH OUT_PATH SAMPLE_NAME
