#!/bin/bash

# Savana V1.0.3
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5


THREADS=32
SIZE=50
#SIZE=30 for COLO829

mamba activate savana

savana --threads $THREADS \
--outdir ${OUT_DIR} \
--tumour ${TUMOR_BAM} \
--normal ${NORMAL_BAM} \
--ref $REF \
--length $SIZE \
--threads $THREADS
