#!/bin/bash
#Severus v1.2
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5


######## SEVERUS

mamba activate severus

python Severus/severus.py \
        --target-bam ${TUMOR_BAM}\
        --control-bam ${NORMAL_BAM}\
        --vntr-bed Severus/vntrs/human_GRCh38_no_alt_analysis_set.trf.bed.gz \
        --out-dir ${OUT_DIR} \
        -t 16 --phasing-vcf ${VCF}
