#!/bin/bash
#Minda commit id:2066ef5
SIZE=30 #for COLO829
SIZE=50 # for others
python minda/minda.py truthset --base $TRUTH_VCF --vcfs $CALLER_VCF --min_size $SIZE --tolerance 500 --out_dir minda_out
   
python minda/minda.py truthset --base $TRUTH_VCF --vcfs $CALLER_VCF --min_size $SIZE --tolerance 500 --out_dir minda_out --vaf 0.1

# For ensemble 
python minda/minda.py ensemble --min_size $SIZE --tolerance 500 --conditions "[[[caller_names[:4], caller_names[4:8], caller_names[8:11]], '>=', 2],'&', [caller_names,'>=', 4]]" --out_dir minda_4_2/ --tsv samples.tsv

#VAF for COLO829
python minda/minda.py ensemble --min_size $SIZE --tolerance 500 --conditions "[[[caller_names[:4], caller_names[4:8], caller_names[8:11]], '>=', 2],'&', [caller_names,'>=', 4]]" --out_dir minda_4_2_vaf/ --tsv samples_vaf.tsv --vaf 0.1

