#!/bin/bash
module load minimap2
module load samtools
BAM_PATH=$1
REF_PATH=$2
SAMPLE_NAME=$3

cd ${BAM_PATH}
samtools merge -@ 8 merged.bam  *.bam
samtools fastq -T MM,ML merged.bam | minimap2 -ax map-hifi ${REF_PATH} - -k 17 -y -K 5G -t 56 --eqx | samtools sort -@4 -m 4G > ${SAMPLE_NAME}.bam
samtools index -@56 ${SAMPLE_NAME}.bam

#sbatch --gres=lscratch:2000  --cpus-per-task=56 --time 48:00:00 --mail-type=END alignment_bam_hifi.sh BAM_PATH REF_PATH OUT_PATH_SAMPLE_NAME
