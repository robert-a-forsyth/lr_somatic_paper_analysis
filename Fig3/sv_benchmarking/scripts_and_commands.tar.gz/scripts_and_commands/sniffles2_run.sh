#!/bin/bash
# Sniffles2 v2.2
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

############### SNIFFLES2

THREADS=16
SIZE=50

#sniffles
module load sniffles/2.2

sniffles --input ${TUMOR_BAM} \
--vcf $OUT_DIR/sniffles_tumor.vcf \
--snf $OUT_DIR/sniffles_tumor.snf \
--tandem-repeats $TANDEM_REPEATS \
--reference $REF \
--threads $THREADS \
--minsvlen $SIZE --allow-overwrite

sniffles --input ${NORMAL_BAM} \
--vcf ${OUT_DIR}/sniffles_normal.vcf \
--snf ${OUT_DIR}/sniffles_normal.snf \
--tandem-repeats $TANDEM_REPEATS \
--reference $REF \
--threads $THREADS \
--minsvlen $SIZE --allow-overwrite

sniffles --input $OUT_DIR/sniffles_normal.snf $OUT_DIR/sniffles_tumor.snf \
 --vcf $OUT_DIR/merge_normal_tumor.vcf --allow-overwrite

module load bcftools
bcftools view -i "SUPP_VEC = '01'" $OUT_DIR/merge_normal_tumor.vcf > $OUT_DIR/merge_somatic_only.vcf
