#!/bin/bash

# DeBreak v1.2

mamba activate debreak
debreak -t 32 --bam ${TUMOR_BAM} -o $OUT_DIR

#### truvaru subtraction

mamba activate truvari

truvari bench -c $CALLER_VCF -b $TRUTH_VCF--typeignore --dup-to-ins -p 0 -s 30 -S 0 --sizemax 100000000 -o truvari_output --passonly

###### jasmine
mamba activate jasminesv
ls *.vcf > filelist.txt
jasmine file_list=filelist.txt --dup_to_ins max_dist 500 genome_file=$REF out_file=merged.vcf
bcftools view -i "SUPP_VEC = '01'" merged.vcf > merge_somatic_only.vcf
bgzip -c merge_somatic_only.vcf > merge_somatic_only.vcf.gz
tabix merge_somatic_only.vcf.gz 
