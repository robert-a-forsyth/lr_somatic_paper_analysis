#!/bin/bash
TUMOR_BAM=$1
NORMAL_BAM=$2
VCF=$3
OUT_DIR=$4
REF=$5

## MANTA v 1.6.0
configManta.py \
   --normalBam=$TUMOR_BAM\
   --tumorBam=${NORMAL_BAM} \
   --referenceFasta=$REF

MantaWorkflow/runWorkflow.py -j 32
